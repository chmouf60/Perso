import sys
import urllib.parse
import urllib.request
import re
import os
import json
import traceback
import xml.etree.ElementTree as ET
import xbmcgui
import xbmcplugin
import xbmc
import xbmcvfs
import xbmcaddon

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
FAV_FILE = os.path.join(PROFILE_PATH, 'favorites.json')
HISTORY_FILE = os.path.join(PROFILE_PATH, 'search_history.json')

if not os.path.exists(PROFILE_PATH): os.makedirs(PROFILE_PATH)

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Referer': 'https://www.naughtyblog.org/'
}


def log(msg, level=xbmc.LOGERROR):
    if level >= xbmc.LOGERROR:
        xbmc.log('[NAblog] ' + str(msg), level)


def notify(title, message):
    try:
        xbmcgui.Dialog().notification(title, str(message), time=4000)
    except:
        pass


def get_favorites():
    if os.path.exists(FAV_FILE):
        try:
            with open(FAV_FILE, 'r') as f: return json.load(f)
        except Exception as e:
            log('get_favorites error: %s' % e)
            return []
    return []


def save_favorites(favs):
    with open(FAV_FILE, 'w') as f: json.dump(favs, f)


def get_history():
    if os.path.exists(HISTORY_FILE):
        try:
            with open(HISTORY_FILE, 'r') as f:
                data = json.load(f)
                return data if isinstance(data, list) else []
        except:
            return []
    return []


def save_history(items):
    with open(HISTORY_FILE, 'w') as f:
        json.dump(items[:20], f)


def add_history(query):
    q = (query or '').strip()
    if not q:
        return
    hist = [x for x in get_history() if x.lower() != q.lower()]
    hist.insert(0, q)
    save_history(hist)


def get_meta(text):
    res_list = ['2160p', '1080p', '720p', '480p', '4K', 'SD']
    r_out = ""
    for r in res_list:
        if r.lower() in text.lower():
            r_out = r.upper()
            break
    if not r_out and '.sd.' in text.lower(): r_out = "SD"
    d_match = re.search(r'(\d{1,3}\s?min|\d{1,2}:\d{2}:\d{2})', text, re.IGNORECASE)
    d_out = d_match.group(1) if d_match else ""
    if d_out and ':' in d_out:
        try:
            h, m, s = [int(x) for x in d_out.split(':')]
            total_min = h * 60 + m + (1 if s >= 30 else 0)
            d_out = f"{total_min} min"
        except:
            pass
    return r_out, d_out


def html_to_text(s):
    s = re.sub(r'<[^>]+>', ' ', s or '')
    s = s.replace('&amp;', '&').replace('&#8211;', '-').replace('&#8217;', "'")
    return re.sub(r'\s+', ' ', s).strip()


def fetch_article_duration(link):
    try:
        req = urllib.request.Request(link, headers=HEADERS)
        with urllib.request.urlopen(req) as resp:
            article_html = resp.read().decode('utf-8', errors='ignore')
        m = re.search(r'<strong>\s*Duration:\s*</strong>\s*([^|<]+)', article_html, re.IGNORECASE)
        if m:
            return re.sub(r'\s+', ' ', m.group(1)).strip()
        return ''
    except Exception:
        return ''


def build_list_url(page, query=None):
    u = f"{BASE_URL}?action=list&page={page}"
    if query:
        u += f"&query={urllib.parse.quote_plus(query)}"
    return u


def build_sites_letter_url(letter, page=1):
    return f"{BASE_URL}?action=sites_by_letter&letter={urllib.parse.quote_plus(letter)}&page={page}"


def build_site_url(page, site_url):
    return f"{BASE_URL}?action=site_list&page={page}&site_url={urllib.parse.quote_plus(site_url)}"


def slug_to_name(slug):
    name = slug.strip('/').split('/')[-1].replace('-', ' ')
    return ' '.join(w.upper() if w.isdigit() else w.capitalize() for w in name.split())


def fetch_sites(letter=None, page=1):
    if letter == '#':
        url = 'https://www.naughtyblog.org/sites/' if int(page) == 1 else f'https://www.naughtyblog.org/sites/page/{page}/'
    elif letter:
        url = f'https://www.naughtyblog.org/sites/?letter={urllib.parse.quote_plus(letter.lower())}'
        if int(page) > 1:
            url += f'&paged={page}'
    else:
        url = 'https://www.naughtyblog.org/sites/'
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req) as resp:
        html = resp.read().decode('utf-8', errors='ignore')
    urls = re.findall(r'https?://www\.naughtyblog\.org/site/[^"\'\s<>]+', html, re.IGNORECASE)
    items = []
    seen = set()
    for url in urls:
        url = url.rstrip('/') + '/'
        if url in seen:
            continue
        seen.add(url)
        slug = url.rstrip('/').split('/')[-1]
        name = slug_to_name(slug)
        items.append((name, url))
    items.sort(key=lambda x: x[0].lower())
    return items


def sites_letters():
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=BASE_URL, listitem=xbmcgui.ListItem(label='[B][COLOR gray]<< Retour au Menu Principal[/COLOR][/B]'), isFolder=True)
    for letter in list('ABCDEFGHIJKLMNOPQRSTUVWXYZ') + ['#']:
        li = xbmcgui.ListItem(label=letter)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_sites_letter_url(letter, 1), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def sites_by_letter(letter, page='1'):
    try:
        page = int(page)
        sites = fetch_sites(letter, page)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{BASE_URL}?action=sites_letters", listitem=xbmcgui.ListItem(label='[B][COLOR gray]<< Retour aux lettres[/COLOR][/B]'), isFolder=True)
        if page > 1:
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_sites_letter_url(letter, page-1), listitem=xbmcgui.ListItem(label=f"[COLOR orange][B]<<< Page Précédente ({page-1})[/B][/COLOR]"), isFolder=True)
        count = 0
        for name, url in sites:
            first = name[:1].upper() if name else '#'
            group = first if first.isalpha() else '#'
            if letter != '#' and group != letter.upper():
                continue
            li = xbmcgui.ListItem(label=name)
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_site_url(1, url), listitem=li, isFolder=True)
            count += 1
        if count == 0:
            xbmcplugin.addDirectoryItem(handle=HANDLE, url='', listitem=xbmcgui.ListItem(label='[COLOR gray]Aucun site pour cette lettre[/COLOR]'), isFolder=False)
        if count > 0:
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_sites_letter_url(letter, page+1), listitem=xbmcgui.ListItem(label=f"[COLOR lime][B]>>> Page Suivante ({page+1})[/B][/COLOR]"), isFolder=True)
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        log('sites_by_letter error: %s' % e)
        log(traceback.format_exc())
        notify('Erreur sites', e)
        xbmcplugin.endOfDirectory(HANDLE)


def list_site_articles(page, site_url):
    page = int(page)
    favs = get_favorites()
    fav_urls = [f['url'] for f in favs]
    url = site_url if page == 1 else site_url.rstrip('/') + f'/page/{page}/'
    try:
        req = urllib.request.Request(url, headers=HEADERS)
        with urllib.request.urlopen(req) as resp:
            html = resp.read().decode('utf-8', errors='ignore')
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{BASE_URL}?action=sites_letters", listitem=xbmcgui.ListItem(label='[B][COLOR gray]<< Retour aux Sites[/COLOR][/B]'), isFolder=True)
        if page > 10:
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_site_url(page-10, site_url), listitem=xbmcgui.ListItem(label=f"[COLOR tomato][B]<< -10 pages ({page-10})[/B][/COLOR]"), isFolder=True)
        if page > 1:
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_site_url(page-1, site_url), listitem=xbmcgui.ListItem(label=f"[COLOR orange][B]<<< Page Précédente ({page-1})[/B][/COLOR]"), isFolder=True)
        seen = set()
        patterns = [
            r'<h(?:1|2|3)[^>]*class=["\'][^"\']*entry-title[^"\']*["\'][^>]*>\s*<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
            r'<a[^>]+href=["\']([^"\']+)["\'][^>]*rel=["\']bookmark["\'][^>]*>(.*?)</a>'
        ]
        for pattern in patterns:
            for m in re.finditer(pattern, html, re.IGNORECASE | re.DOTALL):
                link, raw_title = m.group(1), m.group(2)
                title = html_to_text(raw_title)
                if not link.startswith('http') or not title or link in seen:
                    continue
                seen.add(link)
                next_pos = html.find(link, m.end())
                if next_pos == -1:
                    next_pos = min(len(html), m.end() + 8000)
                block = html[m.start():next_pos]
                img_m = re.search(r"<img[^>]+(?:data-src|data-lazy-src|src)=['\"]([^'\"]+)['\"]", block, re.IGNORECASE)
                thumb = img_m.group(1) if img_m else ''
                li = xbmcgui.ListItem(label=title)
                if thumb:
                    li.setArt({'thumb': thumb, 'icon': thumb})
                u = f"{BASE_URL}?action=scrape&url={urllib.parse.quote_plus(link)}&thumb={urllib.parse.quote_plus(thumb)}&src=search"
                if link in fav_urls:
                    idx = next(i for i, f in enumerate(favs) if f['url'] == link)
                    li.addContextMenuItems([("[COLOR red]Supprimer des Favoris[/COLOR]", f"RunPlugin({BASE_URL}?action=del_fav&index={idx})")])
                else:
                    li.addContextMenuItems([("Ajouter aux Favoris", f"RunPlugin({BASE_URL}?action=add_fav&title={urllib.parse.quote_plus(title)}&url={urllib.parse.quote_plus(link)}&thumb={urllib.parse.quote_plus(thumb)})")])
                xbmcplugin.addDirectoryItem(handle=HANDLE, url=u, listitem=li, isFolder=True)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_site_url(page+1, site_url), listitem=xbmcgui.ListItem(label=f"[COLOR lime][B]>>> Page Suivante ({page+1})[/B][/COLOR]"), isFolder=True)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_site_url(page+10, site_url), listitem=xbmcgui.ListItem(label=f"[COLOR skyblue][B]+10 pages >> ({page+10})[/B][/COLOR]"), isFolder=True)
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        log('list_site_articles error: %s' % e)
        log(traceback.format_exc())
        notify('Erreur site', e)
        xbmcplugin.endOfDirectory(HANDLE)


def main_menu():
    goto_icon = os.path.join(PATH, 'goto.png')
    items = [
        ("Accéder aux articles", f"{BASE_URL}?action=list&page=1", "DefaultFolder.png"),
        ("Favoris", f"{BASE_URL}?action=show_favs", "DefaultAddonService.png"),
        ("Aller à la page", f"{BASE_URL}?action=go_to_page", goto_icon),
        ("Rechercher", f"{BASE_URL}?action=search", "DefaultAddonsSearch.png"),
        ("Historique de recherche", f"{BASE_URL}?action=show_history", "DefaultFile.png"),
        ("Sites", f"{BASE_URL}?action=sites_letters", "DefaultFolder.png")
    ]
    for label, url, icon in items:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': icon, 'thumb': icon})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def list_articles(page, query=None):
    page = int(page)
    favs = get_favorites()
    fav_urls = [f['url'] for f in favs]

    if query:
        url = f"https://www.naughtyblog.org/page/{page}/?s={urllib.parse.quote_plus(query)}"
        if page == 1: url = f"https://www.naughtyblog.org/?s={urllib.parse.quote_plus(query)}"
    else:
        url = f"https://www.naughtyblog.org/feed/?paged={page}"

    try:
        req = urllib.request.Request(url, headers=HEADERS)
        with urllib.request.urlopen(req) as resp: data = resp.read()

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=BASE_URL, listitem=xbmcgui.ListItem(label="[B][COLOR gray]<< Retour au Menu Principal[/COLOR][/B]"), isFolder=True)

        if page > 10:
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_list_url(page-10, query), listitem=xbmcgui.ListItem(label=f"[COLOR tomato][B]<< -10 pages ({page-10})[/B][/COLOR]"), isFolder=True)
        if page > 1:
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_list_url(page-1, query), listitem=xbmcgui.ListItem(label=f"[COLOR orange][B]<<< Page Précédente ({page-1})[/B][/COLOR]"), isFolder=True)

        if query:
            html = data.decode('utf-8', errors='ignore')
            seen = set()
            results = []

            patterns = [
                r'<h(?:1|2|3)[^>]*class=["\'][^"\']*entry-title[^"\']*["\'][^>]*>\s*<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
                r'<a[^>]+href=["\']([^"\']+)["\'][^>]*rel=["\']bookmark["\'][^>]*>(.*?)</a>'
            ]
            for pattern in patterns:
                for link, raw_title in re.findall(pattern, html, re.IGNORECASE | re.DOTALL):
                    title = html_to_text(raw_title)
                    if not link.startswith('http') or not title or link in seen:
                        continue
                    seen.add(link)
                    pos = html.find(link)
                    ctx = html[max(0, pos-4000):pos+12000] if pos != -1 else html
                    img_m = re.search(r'<img[^>]+src=["\']([^"\']+)["\']', ctx, re.IGNORECASE)
                    thumb = img_m.group(1) if img_m else ''
                    results.append((link, title, thumb))

            for link, title, thumb in results:
                label = title
                li = xbmcgui.ListItem(label=label)
                if thumb:
                    li.setArt({'thumb': thumb, 'icon': thumb})
                u = f"{BASE_URL}?action=scrape&url={urllib.parse.quote_plus(link)}&thumb={urllib.parse.quote_plus(thumb)}&src=search"
                if link in fav_urls:
                    idx = next(i for i, f in enumerate(favs) if f['url'] == link)
                    li.addContextMenuItems([("[COLOR red]Supprimer des Favoris[/COLOR]", f"RunPlugin({BASE_URL}?action=del_fav&index={idx})")])
                else:
                    li.addContextMenuItems([("Ajouter aux Favoris", f"RunPlugin({BASE_URL}?action=add_fav&title={urllib.parse.quote_plus(label)}&url={urllib.parse.quote_plus(link)}&thumb={urllib.parse.quote_plus(thumb)})")])
                xbmcplugin.addDirectoryItem(handle=HANDLE, url=u, listitem=li, isFolder=True)
        else:
            root = ET.fromstring(data)
            for item in root.findall('.//item'):
                title = item.find('title').text; link = item.find('link').text
                ce = item.find('{http://purl.org/rss/1.0/modules/content/}encoded')
                content = ce.text if ce is not None else ""
                _, dur = get_meta(content)
                img_m = re.search(r'src=["\']([^"\']+)["\']', content)
                thumb = img_m.group(1) if img_m else ""
                label = f"{title} [COLOR gold]({dur})[/COLOR]" if dur else title
                li = xbmcgui.ListItem(label=label); li.setArt({'thumb': thumb, 'icon': thumb})
                if link in fav_urls:
                    idx = next(i for i, f in enumerate(favs) if f['url'] == link)
                    li.addContextMenuItems([("[COLOR red]Supprimer des Favoris[/COLOR]", f"RunPlugin({BASE_URL}?action=del_fav&index={idx})")])
                else:
                    li.addContextMenuItems([("Ajouter aux Favoris", f"RunPlugin({BASE_URL}?action=add_fav&title={urllib.parse.quote_plus(label)}&url={urllib.parse.quote_plus(link)}&thumb={urllib.parse.quote_plus(thumb)})")])
                u = f"{BASE_URL}?action=scrape&url={urllib.parse.quote_plus(link)}&thumb={urllib.parse.quote_plus(thumb)}&dur={urllib.parse.quote_plus(dur)}"
                xbmcplugin.addDirectoryItem(handle=HANDLE, url=u, listitem=li, isFolder=True)

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_list_url(page+1, query), listitem=xbmcgui.ListItem(label=f"[COLOR lime][B]>>> Page Suivante ({page+1})[/B][/COLOR]"), isFolder=True)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_list_url(page+10, query), listitem=xbmcgui.ListItem(label=f"[COLOR skyblue][B]+10 pages >> ({page+10})[/B][/COLOR]"), isFolder=True)
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        log('list_articles error: %s' % e)
        log(traceback.format_exc())
        notify('Erreur list_articles', e)
        xbmcplugin.endOfDirectory(HANDLE)


def scrape_links(url, thumb="", dur=""):
    try:
        hide_duration = dur == '__HIDE__'
        req = urllib.request.Request(url, headers=HEADERS)
        with urllib.request.urlopen(req) as resp: html = resp.read().decode('utf-8', errors='ignore')
        res_p, dur_p = get_meta(html)
        clean_dur = '' if hide_duration else (dur.split('(')[-1].split(')')[0] if '(' in dur else dur)
        links = re.findall(r'https?://(?:www\.)?(?:rapidgator\.net/file/|rg\.to/file/)[^\s"\'><]+', html)
        for l in list(dict.fromkeys(links)):
            res_l = get_meta(l)[0] or res_p
            pref = ""
            if res_l: pref += f"[COLOR cyan][{res_l}][/COLOR] "
            if not hide_duration and (clean_dur or dur_p): pref += f"[COLOR gold][{clean_dur or dur_p}][/COLOR] "
            fname = l.split('/')[-1].replace('.html', '')
            li = xbmcgui.ListItem(label=f"{pref}{fname}")
            if thumb:
                li.setArt({'thumb': thumb, 'icon': thumb})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{BASE_URL}?action=play&url={urllib.parse.quote_plus(l)}", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        log('scrape_links error: %s' % e)
        log(traceback.format_exc())
        notify('Erreur scrape_links', e)
        xbmcplugin.endOfDirectory(HANDLE)


def play_link(url):
    try:
        import resolveurl
        resolved = resolveurl.resolve(url)
        if resolved: xbmc.Player().play(resolved, xbmcgui.ListItem(path=resolved))
    except Exception as e:
        log('play_link error: %s' % e)
        log(traceback.format_exc())
        notify('Erreur play_link', e)


def manage_favs(action, params):
    favs = get_favorites()
    if action == 'add':
        favs.append({'title': params.get('title'), 'url': params.get('url'), 'thumb': params.get('thumb','')})
        save_favorites(favs); xbmcgui.Dialog().notification("Favoris", "Ajouté !"); xbmc.executebuiltin("Container.Refresh")
    elif action == 'show':
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=BASE_URL, listitem=xbmcgui.ListItem(label="[B][COLOR gray]<< Retour au Menu Principal[/COLOR][/B]"), isFolder=True)
        if favs:
            li_clear = xbmcgui.ListItem(label="[COLOR red][B]Effacer les favoris[/B][/COLOR]")
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{BASE_URL}?action=clear_favs", listitem=li_clear, isFolder=False)
        for i, f in enumerate(favs):
            label = f['title']; li = xbmcgui.ListItem(label=label)
            if f.get('thumb'): li.setArt({'thumb': f['thumb'], 'icon': f['thumb']})
            u = f"{BASE_URL}?action=scrape&url={urllib.parse.quote_plus(f['url'])}&thumb={urllib.parse.quote_plus(f.get('thumb',''))}&dur={urllib.parse.quote_plus(label)}"
            li.addContextMenuItems([("[COLOR red]Supprimer[/COLOR]", f"RunPlugin({BASE_URL}?action=del_fav&index={i})")])
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=u, listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(HANDLE)
    elif action == 'del':
        idx = int(params['index'])
        if 0 <= idx < len(favs): favs.pop(idx); save_favorites(favs); xbmc.executebuiltin("Container.Refresh")
    elif action == 'clear':
        if xbmcgui.Dialog().yesno('Favoris', 'Effacer tous les favoris ?'):
            save_favorites([])
            xbmc.executebuiltin("Container.Refresh")


def show_history():
    hist = get_history()
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=BASE_URL, listitem=xbmcgui.ListItem(label="[B][COLOR gray]<< Retour au Menu Principal[/COLOR][/B]"), isFolder=True)
    if hist:
        li_clear = xbmcgui.ListItem(label="[COLOR red][B]Effacer l'historique[/B][/COLOR]")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{BASE_URL}?action=clear_history", listitem=li_clear, isFolder=False)
    for q in hist:
        li = xbmcgui.ListItem(label=q)
        li.addContextMenuItems([("Supprimer de l'historique", f"RunPlugin({BASE_URL}?action=del_history&query={urllib.parse.quote_plus(q)})")])
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{BASE_URL}?action=list&page=1&query={urllib.parse.quote_plus(q)}", listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def clear_history():
    if xbmcgui.Dialog().yesno('Historique', "Effacer tout l'historique ?"):
        save_history([])
        xbmc.executebuiltin("Container.Refresh")


def del_history(query):
    hist = [x for x in get_history() if x.lower() != query.lower()]
    save_history(hist)
    xbmc.executebuiltin("Container.Refresh")


params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
act = params.get('action')
if not act: main_menu()
elif act == 'list': list_articles(params.get('page', '1'), params.get('query'))
elif act == 'go_to_page':
    p = xbmcgui.Dialog().numeric(0, "Numéro de page")
    if p: list_articles(p)
elif act == 'scrape': scrape_links(params['url'], params.get('thumb',''), params.get('dur','') if params.get('src') != 'search' else '__HIDE__')
elif act == 'search':
    kb = xbmcgui.Dialog().input("Rechercher", type=xbmcgui.INPUT_ALPHANUM)
    if kb:
        add_history(kb)
        list_articles(1, query=kb)
elif act == 'show_history': show_history()
elif act == 'clear_history': clear_history()
elif act == 'del_history': del_history(params.get('query',''))
elif act == 'sites_letters': sites_letters()
elif act == 'sites_by_letter': sites_by_letter(params.get('letter', '#'), params.get('page', '1'))
elif act == 'site_list': list_site_articles(params.get('page', '1'), params.get('site_url', ''))
elif act == 'add_fav': manage_favs('add', params)
elif act == 'show_favs': manage_favs('show', params)
elif act == 'del_fav': manage_favs('del', params)
elif act == 'clear_favs': manage_favs('clear', params)
elif act == 'play': play_link(params['url'])
