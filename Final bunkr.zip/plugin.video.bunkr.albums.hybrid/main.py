# -*- coding: utf-8 -*-
import sys
import re
import json
import base64
import gzip
import zlib
import urllib.parse
import urllib.request
import urllib.error
import http.cookiejar
import os

import xbmc
import xbmcaddon
import xbmcvfs
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else 1
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36'
EXPLORER_API = 'https://data.u4582180137.workers.dev/data'
PAGE_SIZE = 50
BUNKR_DOWN_MODE = False
_album_count_cache = {}
_cookie_jar = http.cookiejar.CookieJar()
_opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(_cookie_jar))
def get_profile_dir():
    try:
        addon = xbmcaddon.Addon()
        return xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    except Exception as exc:
        log('get_profile_dir error: %s' % exc)
        try:
            base = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.bunkr.albums.hybrid/')
            return base
        except Exception:
            return os.path.join(os.path.expanduser('~'), '.kodi', 'userdata', 'addon_data', 'plugin.video.bunkr.albums.hybrid')


def get_favorites_file():
    return os.path.join(get_profile_dir(), 'favorites.json')


def ensure_profile_dir():
    profile_dir = get_profile_dir()
    try:
        if not xbmcvfs.exists(profile_dir):
            xbmcvfs.mkdirs(profile_dir)
    except Exception:
        try:
            os.makedirs(profile_dir, exist_ok=True)
        except Exception:
            pass


def load_favorites():
    ensure_profile_dir()
    try:
        if not xbmcvfs.exists(get_favorites_file()) and not os.path.exists(get_favorites_file()):
            return []
        fh = xbmcvfs.File(get_favorites_file())
        raw = fh.read()
        fh.close()
        if isinstance(raw, bytes):
            raw = raw.decode('utf-8', 'replace')
        data = json.loads(raw or '[]')
        return data if isinstance(data, list) else []
    except Exception as exc:
        log('load_favorites error: %s' % exc)
        return []


def save_favorites(items):
    ensure_profile_dir()
    try:
        fh = xbmcvfs.File(get_favorites_file(), 'w')
        fh.write(json.dumps(items, ensure_ascii=False))
        fh.close()
        return True
    except Exception as exc:
        log('save_favorites error: %s' % exc)
        return False


def is_favorite(album_url):
    for item in load_favorites():
        if item.get('url') == album_url:
            return True
    return False


def add_favorite(album_label, album_url):
    items = load_favorites()
    for item in items:
        if item.get('url') == album_url:
            xbmcgui.Dialog().notification('Bunkr albums', 'Déjà en favori', xbmcgui.NOTIFICATION_INFO)
            return
    items.append({'label': album_label, 'url': album_url})
    if save_favorites(items):
        xbmcgui.Dialog().notification('Bunkr albums', 'Ajouté aux favoris', xbmcgui.NOTIFICATION_INFO)


def remove_favorite(album_url):
    items = load_favorites()
    new_items = [item for item in items if item.get('url') != album_url]
    if save_favorites(new_items):
        xbmcgui.Dialog().notification('Bunkr albums', 'Retiré des favoris', xbmcgui.NOTIFICATION_INFO)




def build_url(query):
    return sys.argv[0] + '?' + urllib.parse.urlencode(query)


def build_search_target(query, page):
    return json.dumps({'q': query or '', 'page': int(page or 1)}, separators=(',', ':'))


def parse_search_target(target):
    try:
        data = json.loads(target or '{}')
        return (data.get('q') or '', int(data.get('page') or 1))
    except Exception:
        return (target or '', 1)


def log(msg):
    try:
        xbmc.log('[bunkr-hybrid] %s' % msg, xbmc.LOGINFO)
    except Exception:
        pass


def normalize_url(url, base_url):
    if not url:
        return ''
    if url.startswith('//'):
        return 'https:' + url
    return urllib.parse.urljoin(base_url, url)


def clean_text(s):
    s = re.sub(r'<[^>]+>', ' ', s or '')
    s = s.replace('&amp;', '&').replace('&quot;', '"').replace('&#39;', "'")
    return ' '.join(s.split()).strip()


def request(url, referer=None, method='GET', data=None, headers=None):
    h = {
        'User-Agent': UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,application/json;q=0.9,*/*;q=0.8',
        'Accept-Language': 'fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7',
        'Accept-Encoding': 'gzip, deflate',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        'Connection': 'keep-alive',
    }
    if referer:
        h['Referer'] = referer
    if headers:
        h.update(headers)
    req = urllib.request.Request(url, data=data, headers=h, method=method)
    with _opener.open(req, timeout=25) as r:
        raw = r.read()
        enc = (r.headers.get('Content-Encoding', '') or '').lower()
        if enc == 'gzip':
            raw = gzip.decompress(raw)
        elif enc == 'deflate':
            raw = zlib.decompress(raw)
        return raw, r.geturl(), r.headers.get('Content-Type', '')


def fetch_html(url, referer=None, headers=None):
    raw, final, ctype = request(url, referer=referer, headers=headers)
    try:
        html = raw.decode('utf-8', 'replace')
    except Exception:
        html = raw.decode('latin-1', 'replace')
    return html, final, ctype


def probe_bunkr_status():
    try:
        req = urllib.request.Request('https://bunkr.cr/', headers={'User-Agent': UA})
        with _opener.open(req, timeout=10) as r:
            return str(getattr(r, 'status', 200) or 200)
    except urllib.error.HTTPError as e:
        try:
            return str(e.code)
        except Exception:
            return 'HTTP?'
    except Exception:
        return 'indisponible'


def add_item(label, action, target='', is_folder=False, playable=False, plot='', thumb='', back_action='', back_url=''):
    li = xbmcgui.ListItem(label=label)
    if playable:
        li.setProperty('IsPlayable', 'true')
    try:
        li.setInfo('video', {'title': label, 'plot': plot or label})
    except Exception:
        pass
    if thumb:
        try:
            li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb, 'fanart': thumb})
        except Exception:
            pass
    if action == 'album' and target:
        fav_label = plot or label
        if is_favorite(target):
            cm_label = 'Retirer des favoris'
            cm_url = build_url({'action': 'fav_remove', 'url': target, 'back_action': back_action, 'back_url': back_url})
            if back_action == 'favorites':
                cm_cmd = 'RunPlugin(%s)' % cm_url
            else:
                cm_cmd = 'RunPlugin(%s)' % cm_url
        else:
            cm_label = 'Ajouter aux favoris'
            cm_url = build_url({'action': 'fav_add', 'url': target, 'label': fav_label, 'back_action': back_action, 'back_url': back_url})
            cm_cmd = 'RunPlugin(%s)' % cm_url
        try:
            li.addContextMenuItems([(cm_label, cm_cmd)])
        except Exception:
            pass
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': action, 'url': target}), li, isFolder=is_folder)


def add_info_item(label):
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'noop'}), xbmcgui.ListItem(label=label), isFolder=False)


def add_nav_item(label, page, color=None):
    low = (label or '').lower()
    if not color:
        if 'suivante' in low:
            color = 'springgreen'
        elif 'précédente' in low or 'precedente' in low:
            color = 'orange'
        else:
            color = 'gold'
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'root', 'page': str(page)}), xbmcgui.ListItem(label='[COLOR %s]%s[/COLOR]' % (color, label)), isFolder=True)


def fetch_explorer_albums(page=1):
    try:
        raw, _, _ = request(
            EXPLORER_API,
            referer='https://bunkr-explorer.pages.dev/',
            headers={'Accept': 'application/json', 'Origin': 'https://bunkr-explorer.pages.dev', 'Accept-Encoding': 'identity'}
        )
        data = json.loads(raw.decode('utf-8', 'replace'))
        all_albums = []
        if isinstance(data, list):
            for page_obj in data:
                if not isinstance(page_obj, dict):
                    continue
                for album in page_obj.get('albums', []):
                    name = album.get('title') or album.get('name') or ''
                    token = album.get('id') or album.get('token') or album.get('slug') or ''
                    count = str(album.get('i_c') or album.get('files') or album.get('count') or '?')
                    if name and token:
                        all_albums.append({'label': name, 'count': count, 'url': 'https://bunkr.cr/a/' + token})
        elif isinstance(data, dict):
            for album in data.get('albums', []):
                name = album.get('title') or album.get('name') or ''
                token = album.get('id') or album.get('token') or album.get('slug') or ''
                count = str(album.get('i_c') or album.get('files') or album.get('count') or '?')
                if name and token:
                    all_albums.append({'label': name, 'count': count, 'url': 'https://bunkr.cr/a/' + token})
        start = (max(1, int(page)) - 1) * PAGE_SIZE
        end = start + PAGE_SIZE
        return all_albums[start:end], end < len(all_albums), len(all_albums)
    except Exception as exc:
        return None, False, str(exc)


def fetch_all_explorer_albums():
    try:
        raw, _, _ = request(
            EXPLORER_API,
            referer='https://bunkr-explorer.pages.dev/',
            headers={'Accept': 'application/json', 'Origin': 'https://bunkr-explorer.pages.dev', 'Accept-Encoding': 'identity'}
        )
        data = json.loads(raw.decode('utf-8', 'replace'))
        all_albums = []
        if isinstance(data, list):
            for page_obj in data:
                if not isinstance(page_obj, dict):
                    continue
                for album in page_obj.get('albums', []):
                    name = album.get('title') or album.get('name') or ''
                    token = album.get('id') or album.get('token') or album.get('slug') or ''
                    count = str(album.get('i_c') or album.get('files') or album.get('count') or '?')
                    if name and token:
                        all_albums.append({'label': name, 'count': count, 'url': 'https://bunkr.cr/a/' + token})
        elif isinstance(data, dict):
            for album in data.get('albums', []):
                name = album.get('title') or album.get('name') or ''
                token = album.get('id') or album.get('token') or album.get('slug') or ''
                count = str(album.get('i_c') or album.get('files') or album.get('count') or '?')
                if name and token:
                    all_albums.append({'label': name, 'count': count, 'url': 'https://bunkr.cr/a/' + token})
        return all_albums
    except Exception as exc:
        log('search load error: %s' % exc)
        return None


def extract_title(html):
    for pat in [r'<meta[^>]+property=["\']og:title["\'][^>]+content=["\']([^"\']+)', r'<title[^>]*>(.*?)</title>']:
        m = re.search(pat, html, re.I | re.S)
        if m:
            return clean_text(m.group(1))
    return 'Bunkr'


def is_video_file(entry):
    extension = str(entry.get('extension') or '').lower()
    mtype = str(entry.get('type') or '').lower()
    name = str(entry.get('original') or entry.get('name') or '')
    low = name.lower()
    return extension == 'video' or 'video/' in mtype or low.endswith(('.mp4', '.mkv', '.avi', '.mov', '.wmv', '.webm', '.m4v'))


def parse_size_value(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def human_size(num):
    try:
        n = float(int(num))
        units = ['B', 'KB', 'MB', 'GB', 'TB']
        i = 0
        while n >= 1024 and i < len(units) - 1:
            n /= 1024.0
            i += 1
        return '%.1f %s' % (n, units[i])
    except Exception:
        return ''


def colorize_album_weight(size_bytes):
    size_value = parse_size_value(size_bytes)
    size_label = human_size(size_value) or '0 B'
    gb = float(size_value) / float(1024 ** 3)
    if gb < 1:
        return size_label
    if gb <= 50:
        return '[COLOR yellow]%s[/COLOR]' % size_label
    if gb <= 100:
        return '[COLOR deeppink]%s[/COLOR]' % size_label
    return '[COLOR red]%s[/COLOR]' % size_label


def parse_album_files_from_html(html, final_url):
    items = []
    title = extract_title(html)

    marker = 'window.albumFiles'
    pos = html.find(marker)
    if pos == -1:
        log('window.albumFiles absent')
        return title, []

    raw = html[pos:pos + 50000]
    log('albumFiles marker found len=%d' % len(raw))

    pattern = re.compile(
        r"id\s*:\s*(\d+).*?"
        r"original\s*:\s*['\"]([^'\"]+)['\"].*?"
        r"slug\s*:\s*['\"]([^'\"]+)['\"].*?"
        r"type\s*:\s*['\"]([^'\"]+)['\"].*?"
        r"extension\s*:\s*['\"]([^'\"]+)['\"].*?"
        r"size\s*:\s*(\d+).*?"
        r"thumbnail\s*:\s*['\"]([^'\"]+)['\"]",
        re.I | re.S
    )
    blocks = pattern.findall(raw)
    log('albumFiles parsed blocks=%d' % len(blocks))

    for fid, original, slug, mtype, extension, size, thumb in blocks:
        entry = {'original': original, 'name': slug, 'type': mtype, 'extension': extension}
        if not is_video_file(entry):
            continue
        name = (original or slug or fid).strip()
        thumb = normalize_url((thumb or '').strip(), final_url)
        size_value = parse_size_value(size)
        size_label = human_size(size_value)
        label = '%s [%s]' % (name, size_label) if size_label else name
        items.append({'label': label, 'target': 'id:%s' % fid, 'thumb': thumb, 'plot': title, 'size': size_value})

    if not items:
        log('albumFiles no regex matches, trying /f/ fallback')
        seen = set()
        for href in re.findall(r"href=[\"']([^\"']+/f/[^\"']+|/f/[^\"']+)[\"']", html, re.I):
            full = normalize_url(href, final_url)
            slug = full.rstrip('/').rsplit('/', 1)[-1]
            if slug in seen:
                continue
            seen.add(slug)
            if not is_video_file({'name': slug, 'type': '', 'extension': ''}):
                continue
            items.append({'label': slug, 'target': 'slug:%s' % slug, 'thumb': '', 'plot': title, 'size': 0})
        log('fallback items=%d' % len(items))

    items.sort(key=lambda x: parse_size_value(x.get('size')), reverse=True)
    return title, items


def get_exact_album_stats(album_url):
    cached = _album_count_cache.get(album_url)
    if cached is not None:
        return cached
    try:
        sep = '&' if '?' in album_url else '?'
        html, final_url, _ = fetch_html(album_url + sep + 'advanced=1', referer='https://bunkr-explorer.pages.dev/')
        _, items = parse_album_files_from_html(html, final_url)
        count = len(items)
        total_size = sum(parse_size_value(item.get('size')) for item in items)
        stats = {'count': count, 'total_size': total_size}
        _album_count_cache[album_url] = stats
        return stats
    except Exception as exc:
        log('stats error %s => %s' % (album_url, exc))
        return None


def decrypt_bunkr_url(enc_b64, secret_key):
    data = base64.b64decode(enc_b64)
    key = secret_key.encode('utf-8')
    out = bytes(b ^ key[i % len(key)] for i, b in enumerate(data))
    return out.decode('utf-8', 'replace')


def resolve_via_api(file_id, ogname=''):
    payload = json.dumps({'id': str(file_id)}).encode('utf-8')
    raw, _, _ = request(
        'https://apidl.bunkr.ru/api/_001_v2',
        referer='https://get.bunkrr.su/',
        method='POST',
        data=payload,
        headers={'Content-Type': 'application/json', 'Accept': 'application/json', 'Origin': 'https://get.bunkrr.su'}
    )
    j = json.loads(raw.decode('utf-8', 'replace'))
    if not j.get('url'):
        raise RuntimeError('api bunkr sans url')
    ts = int(j.get('timestamp', 0))
    secret = 'SECRET_KEY_%s' % (ts // 3600)
    final = decrypt_bunkr_url(j.get('url', ''), secret)
    if ogname:
        final += ('&' if '?' in final else '?') + 'n=' + urllib.parse.quote(ogname)
    return final


def resolve_target(target):
    if target.startswith('id:'):
        return resolve_via_api(target.split(':', 1)[1], '')
    if target.startswith('slug:'):
        slug = target.split(':', 1)[1]
        page_url = 'https://bunkr.cr/f/' + slug
        html1, url1, _ = fetch_html(page_url, referer='https://bunkr.cr/')
        ogm = re.search(r'ogname\s*=\s*["\']([^"\']+)["\']', html1, re.I)
        ogname = ogm.group(1) if ogm else ''
        for pat in [r'data-id=["\'](\d+)["\']', r'data-file-id=["\'](\d+)["\']', r'/file/(\d+)', r'["\']id["\']\s*:\s*["\']?(\d+)["\']?']:
            m = re.search(pat, html1, re.I)
            if m:
                return resolve_via_api(m.group(1), ogname)
        m = re.search(r'href=["\']([^"\']*?/get/[^"\']+)["\']', html1, re.I)
        if m:
            step2 = normalize_url(m.group(1), url1)
            html2, url2, _ = fetch_html(step2, referer=url1)
            ogm2 = re.search(r'ogname\s*=\s*["\']([^"\']+)["\']', html2, re.I)
            ogname2 = ogm2.group(1) if ogm2 else ''
            for pat in [r'data-id=["\'](\d+)["\']', r'data-file-id=["\'](\d+)["\']', r'/file/(\d+)', r'["\']id["\']\s*:\s*["\']?(\d+)["\']?']:
                mm = re.search(pat, html2, re.I)
                if mm:
                    return resolve_via_api(mm.group(1), ogname2)
    raise RuntimeError('cible non resolue')




def browse_root(page=1):
    page = max(1, int(page))
    albums, has_next, meta = fetch_explorer_albums(page)
    if albums is None:
        add_info_item('Erreur chargement albums: ' + str(meta)[:150])
        xbmcplugin.endOfDirectory(HANDLE)
        return
    total_albums = int(meta) if str(meta).isdigit() else 0
    total_pages = max(1, (total_albums + PAGE_SIZE - 1) // PAGE_SIZE) if total_albums else page + (1 if has_next else 0)
    if BUNKR_DOWN_MODE:
        status = probe_bunkr_status()
        add_info_item('Bunkr indisponible pour le moment (HTTP %s)' % status)
        add_info_item('Les albums sont visibles, mais leur ouverture est temporairement HS')
    add_item('[COLOR gold]Favoris[/COLOR]', 'favorites', '', is_folder=True, plot='Albums favoris')
    add_item('[COLOR deepskyblue]Rechercher[/COLOR]', 'search', '', is_folder=True, plot='Rechercher un album par mot-clé')
    if page > 1:
        add_nav_item('< Page précédente (%d/%d)' % (page - 1, total_pages), page - 1, 'orange')
    visible_count = 0
    for album in albums:
        stats = get_exact_album_stats(album['url'])
        if stats is None:
            shown_count = album['count']
            total_size_label = '?'
        else:
            shown_count = stats['count']
            if shown_count <= 0:
                continue
            total_size_label = colorize_album_weight(stats['total_size'])
        visible_count += 1
        album_label = '%s (%s fichiers - %s)' % (album['label'], shown_count, total_size_label)
        add_item(album_label, 'album', album['url'], is_folder=True, plot=album['label'], back_action='root', back_url=str(page))
    if has_next:
        add_nav_item('Page suivante > (%d/%d)' % (page + 1, total_pages), page + 1, 'springgreen')
    if visible_count == 0:
        add_info_item('Aucun album avec vidéo sur cette page')
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)

def browse_favorites():
    items = load_favorites()
    add_item('[COLOR gold]Favoris[/COLOR]', 'favorites', '', is_folder=True, plot='Albums favoris')
    add_item('[COLOR deepskyblue]Rechercher[/COLOR]', 'search', '', is_folder=True, plot='Rechercher un album par mot-clé')
    if not items:
        add_info_item('Aucun favori enregistré')
        xbmcplugin.endOfDirectory(HANDLE)
        return
    visible = 0
    for item in items:
        album_url = item.get('url') or ''
        album_name = item.get('label') or album_url
        stats = get_exact_album_stats(album_url)
        if stats is not None and stats.get('count', 0) <= 0:
            continue
        if stats is None:
            shown_count = '?'
            total_size_label = '?'
        else:
            shown_count = stats['count']
            total_size_label = colorize_album_weight(stats['total_size'])
        label = '★ %s (%s fichiers - %s)' % (album_name, shown_count, total_size_label)
        add_item(label, 'album', album_url, is_folder=True, plot=album_name, back_action='favorites', back_url='')
        visible += 1
    if visible == 0:
        add_info_item('Aucun favori avec vidéo disponible')
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)


def return_to_context(back_action, back_url):
    if back_action == 'search':
        q, p = parse_search_target(back_url)
        search_albums(q, p)
        return
    if back_action == 'favorites':
        browse_favorites()
        return
    if back_action == 'root':
        try:
            browse_root(int(back_url or 1))
        except Exception:
            browse_root(1)
        return
    browse_root(1)


def add_favorite_route(album_url, album_label, back_action='', back_url=''):
    add_favorite(album_label, album_url)


def remove_favorite_route(album_url, back_action='', back_url=''):
    remove_favorite(album_url)


def search_albums(query='', page=1):
    page = max(1, int(page))
    if not query:
        kb = xbmc.Keyboard('', 'Rechercher un album')
        kb.doModal()
        if not kb.isConfirmed():
            xbmcplugin.endOfDirectory(HANDLE)
            return
        query = (kb.getText() or '').strip()
    if not query:
        add_info_item('Recherche vide')
        xbmcplugin.endOfDirectory(HANDLE)
        return
    albums = fetch_all_explorer_albums()
    if albums is None:
        add_info_item('Erreur chargement recherche')
        xbmcplugin.endOfDirectory(HANDLE)
        return
    q = query.lower()
    matches = []
    for album in albums:
        label_low = (album.get('label') or '').lower()
        if q in label_low:
            matches.append(album)
    total = len(matches)
    start_idx = (page - 1) * PAGE_SIZE
    end_idx = start_idx + PAGE_SIZE
    page_matches = matches[start_idx:end_idx]
    total_pages = max(1, (total + PAGE_SIZE - 1) // PAGE_SIZE)
    add_item('[COLOR deepskyblue]Nouvelle recherche[/COLOR]', 'search', '', is_folder=True, plot='Lancer une nouvelle recherche')
    if page > 1:
        add_item('[COLOR orange]< Page précédente (%d/%d)[/COLOR]' % (page - 1, total_pages), 'search', build_search_target(query, page - 1), is_folder=True, plot='Résultats précédents')
    visible_count = 0
    for album in page_matches:
        stats = get_exact_album_stats(album['url'])
        if stats is not None and stats.get('count', 0) <= 0:
            continue
        if stats is None:
            shown_count = album['count']
            total_size_label = '?'
        else:
            shown_count = stats['count']
            total_size_label = colorize_album_weight(stats['total_size'])
        visible_count += 1
        album_label = '%s (%s fichiers - %s)' % (album['label'], shown_count, total_size_label)
        add_item(album_label, 'album', album['url'], is_folder=True, plot=album['label'], back_action='search', back_url=build_search_target(query, page))
    if page < total_pages:
        add_item('[COLOR springgreen]Page suivante > (%d/%d)[/COLOR]' % (page + 1, total_pages), 'search', build_search_target(query, page + 1), is_folder=True, plot='Résultats suivants')
    if total == 0:
        add_info_item('Aucun album trouvé')
    elif visible_count == 0:
        add_info_item('Aucun album avec vidéo sur cette page de résultats')
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)



def open_album(album_url):
    try:
        sep = '&' if '?' in album_url else '?'
        html, final_url, _ = fetch_html(album_url + sep + 'advanced=1', referer='https://bunkr-explorer.pages.dev/')
        title, items = parse_album_files_from_html(html, final_url)
        if not items:
            add_info_item('Aucun fichier détecté')
            add_info_item('Source chargée: ' + final_url[:90])
            add_info_item('Diagnostic: window.albumFiles ou regex KO')
        else:
            for item in items:
                add_item(item['label'], 'resolve', item['target'], is_folder=False, playable=True, plot=title, thumb=item['thumb'])
        xbmcplugin.setPluginCategory(HANDLE, title)
        xbmcplugin.setContent(HANDLE, 'videos')
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as exc:
        msg = str(exc)[:150]
        if 'HTTP Error' in msg or 'Internal Server Error' in msg or 'HTTPError' in msg:
            status = probe_bunkr_status()
            add_info_item('Bunkr indisponible pour le moment (HTTP %s)' % status)
            add_info_item('Les albums sont visibles, mais leur ouverture est temporairement HS')
        else:
            add_info_item('Erreur album: ' + msg)
        xbmcplugin.endOfDirectory(HANDLE)


def resolve_entry(target):
    try:
        final = resolve_target(target)
        headers = 'User-Agent=' + urllib.parse.quote(UA) + '&Referer=' + urllib.parse.quote('https://get.bunkrr.su/')
        li = xbmcgui.ListItem(path=final + '|' + headers)
        li.setProperty('IsPlayable', 'true')
        li.setContentLookup(False)
        li.setMimeType('video/mp4')
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
    except Exception as exc:
        try:
            xbmc.log('[bunkr-hybrid] resolve error: %s' % str(exc), xbmc.LOGERROR)
        except Exception:
            pass
        xbmcgui.Dialog().notification('Bunkr Albums', 'Erreur lecture: %s' % str(exc)[:120], xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get('action', '')
    page = params.get('page', '1')
    url = params.get('url', '')
    label = params.get('label', '')
    back_action = params.get('back_action', '')
    back_url = params.get('back_url', '')
    if action in ('', 'root'):
        browse_root(page)
    elif action == 'album':
        open_album(url)
    elif action == 'favorites':
        browse_favorites()
    elif action == 'fav_add':
        add_favorite_route(url, label, back_action, back_url)
    elif action == 'fav_remove':
        remove_favorite_route(url, back_action, back_url)
    elif action == 'search':
        q, p = parse_search_target(url)
        search_albums(q, p)
    elif action == 'resolve':
        resolve_entry(url)
    else:
        browse_root(1)


if __name__ == '__main__':
    router(sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith('?') else '')
